import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Task } from '../addtask/task';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' ,'headers':'GET, POST, DELETE, PUT'})
};

const header = new HttpHeaders({
  'Content-Type': 'application/json',
  'Accept': '*/*'
});

@Injectable()
export class TaskService {
  private apiUrl = 'http://localhost:8181';
  
  constructor(private http: HttpClient) { }

  public addTask(task) {  
    
    return this.http.post<Task>(this.apiUrl+'/addTask', task, {headers : header});
  }

  public viewTask() {
    return this.http.get<Task[]>(this.apiUrl+'/viewTask', {headers : header});
  }
  public updateTask(task){
    return this.http.post<string>(this.apiUrl+'/updateTask/',task, {headers : header});
  }

  public endTask(taskId){
    return this.http.get<Task[]>(this.apiUrl+'/deleteTask/'+taskId);
      }

  editTask: any = {};
}