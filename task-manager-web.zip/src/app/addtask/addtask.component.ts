import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {TaskService} from '../service/task.service';
import { Task } from './task';
import { Router } from '@angular/router';
 


@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html'
})
export class AddtaskComponent implements OnInit {
  task: Task = new Task();
   
  constructor(private router: Router,private taskervice: TaskService) {
     
   }
   error:any={isError:false,errorMessage:''};
   
   compareTwoDates(){
     this.error={isError:false,errorMessage:''};
      if(new Date(this.task.endDate)<new Date(this.task.startDate)){
         this.error={isError:true,errorMessage:'Start date should be prior to end date.'};
      }
   }

   addTask(): void {

    console.log(this.task.task);
    this.task.status="active";
    console.log(this.task.status);
    console.log(this.task.startDate);
    
    this.taskervice.addTask(this.task)
        .subscribe( data => {
        });

  };

  ngOnInit() {
    this.addTask();
  }
  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }

    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }
}