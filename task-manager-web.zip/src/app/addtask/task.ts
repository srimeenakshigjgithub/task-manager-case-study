export class Task {
  
  
   public task: string;
   public priority: number;
   public parentTask: string;
   public startDate: Date;
   public endDate: Date;
   public taskId: number;
   public parentTaskId: number;
   public status: string;
 

}