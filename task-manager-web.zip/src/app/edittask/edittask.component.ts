import { Component, OnInit } from '@angular/core';
import {TaskService} from '../service/task.service';
import { Task } from '../addtask/task';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edittask',
  templateUrl: './edittask.component.html'
})
export class EdittaskComponent implements OnInit {
  task: Task = new Task();
  constructor(private router: Router,private taskService: TaskService) {
  }

  ngOnInit() {
    this.task = this.taskService.editTask;
  }

  updateTask(task): void {
  this.taskService.updateTask(task)
    .subscribe( data => {
 
     },
      error => {
        
     });
     this.router.navigate(['/viewtask']);
};

}