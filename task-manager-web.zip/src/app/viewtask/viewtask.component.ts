import { Component, OnInit,Pipe, PipeTransform } from '@angular/core';
import {TaskService} from '../service/task.service';
import { Task } from '../addtask/task';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewtask',
  templateUrl: './viewtask.component.html'
})
 
export class ViewtaskComponent implements OnInit{
 

  task: Task = new Task();
  taskList: any[] = [];
  constructor(private router: Router,private taskService: TaskService) {
  }
   

  viewTask(): void {
   this.taskService.viewTask()
       .subscribe( data => {
         this.taskList = data;
       },
       error => {
      });


 };


editTask(task : any){
  this.taskService.editTask = task;
  this.router.navigate(['/edittask']);
  
}

endTask(task : any){
  this.taskService.endTask(task.taskId)
  .subscribe( data => {
    this.taskList = data;
  },error => {
     alert("ERROR");
   });
  
}

  ngOnInit() {
  this.viewTask();
 }


}